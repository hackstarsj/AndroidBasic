package androidbasic.supercoders.in.androidbasic;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText username;
    EditText password;
    TextView signup;
    Button Login;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        username=(EditText)findViewById(R.id.editText);
        password=(EditText)findViewById(R.id.editText2);
        Login=(Button)findViewById(R.id.button);
        signup=(TextView)findViewById(R.id.signup);

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent=new Intent(MainActivity.this,SignupActivity.class);
                //====lets pass some data==

                intent.putExtra("id","ok");
                //===first is key and second is value.

                startActivity(intent);

                //==now pass the intent object in startactivity.
            }
        });



        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(username.getText().toString().isEmpty()){
                    username.setError("Please enter Username");
                }
                else if(password.getText().toString().isEmpty()){
                    password.setError("Please Enter Password");
                }
                else{
                    Toast.makeText(MainActivity.this, "Username "+username.getText().toString(), Toast.LENGTH_SHORT).show();
                    Toast.makeText(MainActivity.this, "Password "+password.getText().toString(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
